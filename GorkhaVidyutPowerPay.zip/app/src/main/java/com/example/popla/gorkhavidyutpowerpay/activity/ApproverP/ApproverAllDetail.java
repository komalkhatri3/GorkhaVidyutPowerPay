package com.example.popla.gorkhavidyutpowerpay.activity.ApproverP;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.popla.gorkhavidyutpowerpay.R;

public class ApproverAllDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_approver_all_detail);
    }
}
