package com.example.popla.gorkhavidyutpowerpay.activity.Applier;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.popla.gorkhavidyutpowerpay.R;

public class ApplierDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_applier_detail);
    }
}
